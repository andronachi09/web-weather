export type ErrorResponse = {
    statusCode: number,
    messageError: string;
};